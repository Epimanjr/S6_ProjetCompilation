package Exception;

public class VariableNonDefinie extends Exception {

	    private String variable;
	   
	    
	    public VariableNonDefinie(String message){
	    	super(message);
	    }
}
