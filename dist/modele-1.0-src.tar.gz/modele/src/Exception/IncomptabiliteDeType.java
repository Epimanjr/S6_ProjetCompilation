package Exception;

public class IncomptabiliteDeType extends Exception {
	private String variable;
	   
    
    public IncomptabiliteDeType(String message){
    	super(message);
}
}